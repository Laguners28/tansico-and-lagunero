public abstract class MenuItem {

        protected String name;
        protected double basePrice;
        private String itemCode;


        public MenuItem() {
            this.name = "Unnamed Item";
            this.basePrice = 0.0;
            this.itemCode = "N/A";
        }

        public MenuItem(String name, double basePrice, String itemCode) {
            this.name = name;
            setBasePrice(basePrice);
            this.itemCode = itemCode;
        }


        public abstract double computePrice();


        public String getDescription() {
            return name + " (Code: " + itemCode + ")";
        }


        public String getName() {
            return name;
        }


        public void setName(String name) {
            if (name != null && !name.isEmpty()) {
                this.name = name;
            } else {
                System.out.println("Invalid item name.");
            }
        }


        public double getBasePrice() {
            return basePrice;
        }

        public void setBasePrice(double basePrice) {
            if (basePrice >= 0) {
                this.basePrice = basePrice;
            } else {
                System.out.println("Error: Price cannot be negative.");
            }
        }


        public String getItemCode() {
            return itemCode;
        }


        public void setItemCode(String itemCode) {
            if (itemCode != null && !itemCode.isEmpty()) {
                this.itemCode = itemCode;
            }
        }
}
